package com.example.myapplication.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.bean.MainContentBean;
import com.example.myapplication.db.SQLiteDatabaseDao;

import java.util.List;

public class SaveActivity extends AppCompatActivity {

    protected TextView idTvContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_save);
        initView();
        new Thread(){
            @Override
            public void run() {
                super.run();
                List<MainContentBean> mainContentBeanList = SQLiteDatabaseDao.getInstance().init(SaveActivity.this).queryMainContent();
                //This is just for display, so we only got the latest one.
                final MainContentBean mainContentBean = mainContentBeanList.get(mainContentBeanList.size()-1);
                SaveActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        idTvContent.setText(mainContentBean.toString());
                    }
                });
            }
        }.start();
    }

    private void initView() {
        idTvContent = findViewById(R.id.id_tv_content);
    }
}
