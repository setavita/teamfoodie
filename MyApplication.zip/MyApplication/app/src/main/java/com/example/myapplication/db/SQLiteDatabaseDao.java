package com.example.myapplication.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.myapplication.bean.IngredientBean;
import com.example.myapplication.bean.MainContentBean;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

public class SQLiteDatabaseDao {

    private static final String TAG = "SQLiteDatabaseDao";

    private static final String DATABASE_NAME = "cate_database";

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_MAIN_CONTENT_TABLE = "main_content";


    public static final String KEY_TITLE = "title";
    public static final String KEY_INTRODUCTION = "introduction";
    public static final String KEY_INGREDIENTS = "ingredients";
    public static final String KEY_PROCEDURES = "procedures";
    public static final String KEY_COOKING_TIME = "cooking_time";
    public static final String KEY_NUTRITIONAL_COUNT = "nutritional_count";
    public static final String KEY_TAGS = "tags";

    private static final String CREATE_CITY_TABLE = "CREATE TABLE IF NOT EXISTS " + DATABASE_MAIN_CONTENT_TABLE + " (id integer primary key autoincrement, "
            + KEY_TITLE + " text not null,  " + KEY_INTRODUCTION + " text not null, " + KEY_INGREDIENTS + " text not null, " + KEY_PROCEDURES
            + " text not null, " + KEY_COOKING_TIME + " text not null, " + KEY_NUTRITIONAL_COUNT + " text not null, " + KEY_TAGS + " text not null);";

    private static List<String> tables;

    private Context mCtx;

    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    /**
     * Database assistant class
     */
    private static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        /**
         * Create table
         *
         * @param db
         */
        @Override
        public void onCreate(SQLiteDatabase db) {
            for (String tableSql : tables) {
                Log.i(TAG, "Creating DataBase: " + tableSql);
                db.execSQL(tableSql);
            }
        }

        /**
         * update version
         *
         * @param db
         * @param oldVersion
         * @param newVersion
         */
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);
        }
    }

    private static class Singleton {
        private static final SQLiteDatabaseDao INSTANCE = new SQLiteDatabaseDao();
    }


    /**
     * get singleton
     *
     * @return
     */
    public static SQLiteDatabaseDao getInstance() {
        return SQLiteDatabaseDao.Singleton.INSTANCE;
    }

    /**
     * initial context
     *
     * @param ctx
     */
    public SQLiteDatabaseDao init(Context ctx) {
        this.mCtx = ctx;
        tables = new ArrayList<>();
        tables.add(CREATE_CITY_TABLE);
        openDb();
        return this;
    }

    /**
     * open database
     *
     * @return
     * @throws SQLException
     */
    private SQLiteDatabaseDao openDb() throws SQLException {
        if (mCtx != null) {
            mDbHelper = new DatabaseHelper(mCtx);
            mDb = mDbHelper.getReadableDatabase();
        }
        return this;
    }

    /**
     * close database
     */
    public void closeDb() {
        mDbHelper.close();
    }

    /**
     * insert content in main content
     *
     * @param mainContentBean
     * @return
     */
    public long insertMainContent(MainContentBean mainContentBean) {
        long result = -1;
        mDb.beginTransaction();
        try {
            ContentValues cityValue = new ContentValues();
            cityValue.put(KEY_TITLE, mainContentBean.getTitle());
            cityValue.put(KEY_INTRODUCTION, mainContentBean.getIntroduction());
            Gson gson = new Gson();
            cityValue.put(KEY_INGREDIENTS, gson.toJson(mainContentBean.getIngredientBeanList()));
            cityValue.put(KEY_PROCEDURES, gson.toJson(mainContentBean.getProcedureList()));
            cityValue.put(KEY_COOKING_TIME, mainContentBean.getCookingTime());
            cityValue.put(KEY_NUTRITIONAL_COUNT, mainContentBean.getNutritionalCount());
            cityValue.put(KEY_TAGS, mainContentBean.getTags());
            result = mDb.insert(DATABASE_MAIN_CONTENT_TABLE, null, cityValue);
            Log.e(TAG, "insertMainContent: result==" + result);
            mDb.setTransactionSuccessful();
        } catch (Exception e) {
        } finally {
            mDb.endTransaction();
        }
        return result;
    }


    /**
     *get the list
     * @return
     */
    public List<MainContentBean> queryMainContent() {
        List<MainContentBean> mainContentBeanList = new ArrayList<>();
        Cursor cursor = null;
        if (cursor == null) {
            String sql = "select * from " + DATABASE_MAIN_CONTENT_TABLE;
            cursor = mDb.rawQuery(sql, null);
        }
        while (cursor.moveToNext()) {
            MainContentBean mainContentBean = new MainContentBean();
            mainContentBean.setTitle(cursor.getString(cursor.getColumnIndex(KEY_TITLE)));
            mainContentBean.setIntroduction(cursor.getString(cursor.getColumnIndex(KEY_INTRODUCTION)));
            String ingredientsStr = cursor.getString(cursor.getColumnIndex(KEY_INGREDIENTS));
            List<IngredientBean> ingredientBeanList = new Gson().fromJson(ingredientsStr, new TypeToken<List<IngredientBean>>() {
            }.getType());
            String proceduresStr = cursor.getString(cursor.getColumnIndex(KEY_PROCEDURES));
            List<String> procedureList = new Gson().fromJson(proceduresStr, new TypeToken<List<String>>() {
            }.getType());
            mainContentBean.setIngredientBeanList(ingredientBeanList);
            mainContentBean.setProcedureList(procedureList);
            mainContentBean.setCookingTime(cursor.getString(cursor.getColumnIndex(KEY_COOKING_TIME)));
            mainContentBean.setNutritionalCount(cursor.getString(cursor.getColumnIndex(KEY_NUTRITIONAL_COUNT)));
            mainContentBean.setTags(cursor.getString(cursor.getColumnIndex(KEY_TAGS)));
            mainContentBeanList.add(mainContentBean);
        }
        cursor.close();
        return mainContentBeanList;
    }

}
