package com.example.myapplication.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.bean.IngredientBean;
import com.example.myapplication.bean.MainContentBean;
import com.example.myapplication.db.SQLiteDatabaseDao;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    protected EditText title;
    protected EditText introduce;
    protected LinearLayout idLlIngredient;
    protected Button addstep;
    protected EditText CTime;
    protected EditText NutritionalCount;
    protected EditText Tag;
    protected Button save;
    protected Button addIngredients;
    protected Button photo;
    protected LinearLayout idLlProcedures;
    protected LinearLayout idLlRoot;

    private List<IngredientBean> mIngredientBeanList;
    private List<String> mProcudureList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_main);
        initView();
        mIngredientBeanList = new ArrayList<>();
        mProcudureList = new ArrayList<>();

        //default add one View of ingredient
        addIngredientView();

        //default add one view of procedures
        addProcedureView();
    }

    private void addIngredientView() {
        View ingredientView = LayoutInflater.from(this).inflate(R.layout.item_ingredient, null, false);
        idLlIngredient.addView(ingredientView);
        final int position = idLlIngredient.getChildCount() - 1;
        Log.d(TAG, "addIngredientView: position==" + position);
        final EditText idEtIngredient = ingredientView.findViewById(R.id.id_et_ingredient);
        final EditText idEtQuantity = ingredientView.findViewById(R.id.id_et_quantity);
        final IngredientBean ingredientBean = new IngredientBean();
        mIngredientBeanList.add(ingredientBean);
        idEtIngredient.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (!b) {
                    IngredientBean ingredientBean = mIngredientBeanList.get(position);
                    ingredientBean.setIngredient(idEtIngredient.getText().toString().trim());
                    mIngredientBeanList.set(position, ingredientBean);
                    Log.d(TAG, "Ingredient  onFocusChange: dismiss fouces ingredientBean===" + ingredientBean.toString());
                }
            }
        });
        idEtQuantity.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (!b) {
                    IngredientBean ingredientBean = mIngredientBeanList.get(position);
                    ingredientBean.setQuantity(idEtQuantity.getText().toString().trim());
                    mIngredientBeanList.set(position, ingredientBean);
                    Log.d(TAG, "Quantity  onFocusChange: dismiss fouces ingredientBean===" + ingredientBean.toString());
                }
            }
        });
    }

    private void addProcedureView() {
        View procudureView = LayoutInflater.from(this).inflate(R.layout.item_procedures, null, false);
        idLlProcedures.addView(procudureView);
        final int position = idLlProcedures.getChildCount() - 1;
        Log.d(TAG, "addProcedureView: position==" + position);
        final EditText idEtProcedure = procudureView.findViewById(R.id.id_et_procedure);
        mProcudureList.add("");
        idEtProcedure.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (!b) {
                    mProcudureList.set(position, idEtProcedure.getText().toString().trim());
                    Log.d(TAG, "Quantity  onFocusChange: dismiss fouces ingredientBean===" + idEtProcedure.getText().toString().trim());
                }
            }
        });
    }

    @Override
    public void onClick(View view) {

        //Because we get the data after we lose focus, we make sure we get the data every time we click on it
        setFoucs(idLlRoot);

        switch (view.getId()) {
            case R.id.addIngredients:
                //add  ingredients
                // from 0 start
                addIngredientView();

                Log.d(TAG, "onClick: mIngredientBeanList==" + mIngredientBeanList.toString());
                break;
            case R.id.addstep:
                //add step
                addProcedureView();
                Log.d(TAG, "onClick: mProcudureList===" + mProcudureList.toString());
                break;
            case R.id.photo:
                break;
            case R.id.save:
                final String titleStr = title.getText().toString().trim();
                checkEmpty(titleStr, "The title cannot be empty ", title);
                final String indroductionStr = introduce.getText().toString().trim();
                checkEmpty(indroductionStr, "The indroduction cannot be empty ", introduce);
                String ingredientStr = mIngredientBeanList.toString();
                if (ingredientStr.contains("null")){
                    showToast("The ingredients have not finished ");
                    return;
                }
                String proceduresStr = mProcudureList.toString();
                if (proceduresStr.contains("null")){
                    showToast("The procedures have not finished ");
                    return;
                }
                final String cookingTimeStr = CTime.getText().toString().trim();
                checkEmpty(cookingTimeStr, "The Cooking Time cannot be empty ", CTime);
                final String nutritionalCountStr = NutritionalCount.getText().toString().trim();
                checkEmpty(nutritionalCountStr, "The Nutritional Count cannot be empty ", NutritionalCount);
                final String tagStr = Tag.getText().toString().trim();
                checkEmpty(tagStr, "The tags cannot be empty ", Tag);

                new Thread(){
                    @Override
                    public void run() {
                        super.run();
                        MainContentBean mainContentBean = new MainContentBean();
                        mainContentBean.setTitle(titleStr);
                        mainContentBean.setIntroduction(indroductionStr);
                        mainContentBean.setIngredientBeanList(mIngredientBeanList);
                        mainContentBean.setProcedureList(mProcudureList);
                        mainContentBean.setCookingTime(cookingTimeStr);
                        mainContentBean.setNutritionalCount(nutritionalCountStr);
                        mainContentBean.setTags(tagStr);
                        long isSucess = SQLiteDatabaseDao.getInstance().init(MainActivity.this).insertMainContent(mainContentBean);
                        if (isSucess!=-1){
                            MainActivity.this.startActivity(new Intent(MainActivity.this, SaveActivity.class));
                            MainActivity.this.finish();
                        }else{
                            showToast("save failed");
                        }
                    }
                }.start();
                break;
        }
    }

    /**
     * Judge the edit box value, if it is empty, give a reminder.
     *
     * @param titleStr
     * @param view
     */
    private void checkEmpty(String titleStr, String msg, View view) {
        if (TextUtils.isEmpty(titleStr)){
            showToast(msg);
            setFoucs(view);
            return;
        }
    }

    /**
     * get focus
     *
     * @param view
     */
    private void setFoucs(View view) {
        view.setFocusable(true);
        view.requestFocus();
        view.setFocusableInTouchMode(true);
        view.requestFocusFromTouch();
    }

    /**
     * pop up toast
     *
     * @param msg
     */
    private void showToast(String msg){
        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
    }

    /**
     * initialization view
     *
     */
    private void initView() {
        title = findViewById(R.id.title);
        introduce = findViewById(R.id.introduce);
        idLlIngredient = findViewById(R.id.id_ll_ingredient);
        addstep = findViewById(R.id.addstep);
        CTime = findViewById(R.id.CTime);
        NutritionalCount = findViewById(R.id.NutritionalCount);
        Tag = findViewById(R.id.Tag);
        save = findViewById(R.id.save);
        addIngredients = findViewById(R.id.addIngredients);
        photo = findViewById(R.id.photo);
        idLlProcedures = findViewById(R.id.id_ll_procedures);
        idLlRoot = findViewById(R.id.id_ll_root);


        addstep.setOnClickListener(MainActivity.this);
        save.setOnClickListener(MainActivity.this);
        addIngredients.setOnClickListener(MainActivity.this);
        photo.setOnClickListener(MainActivity.this);
    }
}
